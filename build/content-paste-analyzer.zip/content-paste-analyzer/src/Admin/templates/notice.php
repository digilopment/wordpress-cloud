<?php ?>
<strong>Content Paste Analyzer:</strong> 
Tento článok obsahuje problematické HTML. Skontrolujte vložené formátovanie a obalujúce &lt;div&gt; tagy.