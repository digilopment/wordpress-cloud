<div class="notice notice-warning">
    <p>
        <?php require_once __DIR__ . '/notice.php'; ?>
    </p>
</div>
